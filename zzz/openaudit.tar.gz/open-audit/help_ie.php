<html>
<body>
<h2>Help : using IE</h2>
<video width='800' controls>
<source src='images/audit_ie.mp4' type='video/mp4'>
Your browser doesn't support HTML5 video.  Please <a href='images/audit_ie.mp4'>download</a> the video and play it locally.
</video>
</body>
</html>
